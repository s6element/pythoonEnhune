#!/usr/bin/env bash
# Вся сборка на раннере. Переменные: TOOLCHAIN (user/repo), FULL (true/false), PYTHON_URL
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TOOLCHAIN="${TOOLCHAIN:-narezany/MargyT}"
PYTHON_URL="${PYTHON_URL:-https://www.python.org/ftp/python/3.14.8/python-3.14.8-aarch64-linux-android.tar.gz}"

echo "::group::тулчейн $TOOLCHAIN"
git clone --depth 1 "https://github.com/$TOOLCHAIN.git" "$ROOT/toolchain" \
    || { echo "::error::не смог склонировать $TOOLCHAIN, впиши живой репо в поле toolchain"; exit 1; }
git -C "$ROOT/toolchain" log -1 --format='%h %s'
echo "::endgroup::"

bash "$ROOT/tests/run.sh" || echo "::warning::хост-тесты упали (на сборку это не влияет)"

bash "$ROOT/scripts/build_mtp.sh" || exit 1

if [ "${FULL:-false}" = "true" ]; then
    echo "::group::питон"
    curl -fsSL "$PYTHON_URL" -o "$ROOT/py.tar.gz" || { echo "::error::не скачался $PYTHON_URL"; exit 1; }
    mkdir -p "$ROOT/pydist" && tar -xzf "$ROOT/py.tar.gz" -C "$ROOT/pydist"
    echo "::endgroup::"
    bash "$ROOT/scripts/assemble_full.sh" "$ROOT/out/margyt.pyengine.mtp" "$ROOT/pydist" || exit 1
fi
ls -la "$ROOT/out"
