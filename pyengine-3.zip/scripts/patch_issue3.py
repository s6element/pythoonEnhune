"""Правка margyt/plugin.py по issue #3 (narezany/MargyT): api не компилится, потому что ссылается на классы мода.
Запуск: python3 patch_issue3.py <путь к margyt/plugin.py>"""
import sys

p = sys.argv[1]
s = open(p, encoding="utf-8").read()
if "API_SOURCE_PATH" in s:
    print("уже пропатчено")
    sys.exit(0)


def rep(old, new):
    global s
    if old not in s:
        print("не нашёл в plugin.py такой кусок:\n" + old)
        sys.exit(2)
    s = s.replace(old, new, 1)


rep('API_SOURCES = os.path.join(ROOT, "inject", "java", "cat", "narezany", "margyt", "plugin")\n',
    'API_SOURCES = os.path.join(ROOT, "inject", "java", "cat", "narezany", "margyt", "plugin")\n'
    '# what the api refers to: the mod itself, and TikTok\'s classes in outline\n'
    'API_SOURCE_PATH = [os.path.join(ROOT, "inject", "java"), os.path.join(ROOT, "inject", "stubs")]\n')
rep('_javac(tools.android_jar, None, api, _java_files(API_SOURCES))',
    '_javac(tools.android_jar, None, api, _java_files(API_SOURCES),\n               source_path=API_SOURCE_PATH)')
rep('def _javac(android_jar: str, extra_classpath, out_dir: str, files) -> None:',
    'def _javac(android_jar: str, extra_classpath, out_dir: str, files, source_path=None) -> None:')
rep('    _run(["javac", "-nowarn", "-Xlint:-options", "-encoding", "UTF-8",\n'
    '          "-cp", classpath, "--release", "17", "-d", out_dir] + list(files))',
    '    command = ["javac", "-nowarn", "-Xlint:-options", "-encoding", "UTF-8",\n'
    '               "-cp", classpath, "--release", "17", "-d", out_dir]\n'
    '    if source_path:\n'
    '        command += ["-sourcepath", os.pathsep.join(source_path), "-implicit:class"]\n'
    '    _run(command + list(files))')
open(p, "w", encoding="utf-8").write(s)
print("пропатчено")
