#!/usr/bin/env bash
# Докладывает в готовый .mtp питон: libpython, stdlib, sdk, libpyjni.so и .plugin из bundled/.
# usage: assemble_full.sh <base.mtp> <PYDIST> ; результат перезаписывает base.mtp
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BASE="$(readlink -f "$1")"; PYDIST="$(readlink -f "$2")"
NDK="${NDK:-${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_HOME:-}}}"
[ -n "$NDK" ] || { echo "::error::не нашёл NDK (ANDROID_NDK_LATEST_HOME)"; exit 1; }
EXCLUDE_EXT="${EXCLUDE_EXT:-_ssl|_hashlib|_sqlite3|_tkinter|_curses|readline|_ctypes_test|_testcapi|xxlimited}"

LIBPY="$(find "$PYDIST" -name 'libpython3*.so' | head -1)"
INC="$(dirname "$(find "$PYDIST" -name Python.h | head -1)")"
STDLIB="$(dirname "$(find "$PYDIST" -name os.py -not -path '*site-packages*' | head -1)")"
DYN="$STDLIB/lib-dynload"
echo "libpython: $LIBPY"; echo "include:   $INC"; echo "stdlib:    $STDLIB"
[ -f "$LIBPY" ] && [ -d "$INC" ] && [ -d "$STDLIB" ] || { echo "::error::раскладка PYDIST не та"; find "$PYDIST" -maxdepth 3 | head -50; exit 1; }

W="$(mktemp -d)"; mkdir "$W/mtp"
(cd "$W/mtp" && unzip -q "$BASE")

CC="$(ls "$NDK"/toolchains/llvm/prebuilt/*/bin/aarch64-linux-android24-clang | head -1)"
"$CC" -shared -fPIC -O2 -Wl,-z,max-page-size=16384 "$ROOT/native/pyjni.c" \
    -I"$INC" -L"$(dirname "$LIBPY")" -l:"$(basename "$LIBPY")" -o "$W/mtp/libpyjni.so"

cp "$LIBPY" "$W/mtp/"
STDZIP="$W/mtp/stdlib.zip"
(cd "$STDLIB" && zip -qr "$STDZIP" . -x 'lib-dynload/*' '*/__pycache__/*' 'test/*' '*/tests/*' \
    'idlelib/*' 'tkinter/*' 'turtledemo/*' 'site-packages/*' 'config-*')
(cd "$ROOT/py" && zip -q "$W/mtp/sdk.zip" ./*.py)
[ -d "$DYN" ] && find "$DYN" -name '*.so' | grep -Ev "$EXCLUDE_EXT" | xargs -r -I{} cp {} "$W/mtp/"
cp "$ROOT"/bundled/*.plugin "$W/mtp/" 2>/dev/null || true

rm -f "$W/out.mtp"
(cd "$W/mtp" && zip -q -r "$W/out.mtp" .)
mv "$W/out.mtp" "$BASE"
echo "готово: $(ls -la "$BASE")"
