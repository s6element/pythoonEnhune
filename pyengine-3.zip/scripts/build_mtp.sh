#!/usr/bin/env bash
# Собирает .mtp тулчейном MargyT (python3 -m margyt.plugin). Результат: out/margyt.pyengine.mtp
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TC="$ROOT/toolchain"
if [ ! -d "$TC/margyt" ]; then
    echo "::error::в toolchain нет пакета margyt, проверь repo/ref тулчейна"; ls "$TC" || true; exit 1
fi
EX="$TC/examples/pyengine"
rm -rf "$EX" && mkdir -p "$EX"
cp -r "$ROOT/plugin/." "$EX/"
cd "$TC"

build() { python3 -m margyt.plugin examples/pyengine 2>&1 | tee /tmp/build.log; return "${PIPESTATUS[0]}"; }

if ! build; then
    if grep -q "cannot find symbol" /tmp/build.log; then
        echo "::warning::api не компилится (issue #3), пробую патч plugin.py"
        python3 "$ROOT/scripts/patch_issue3.py" margyt/plugin.py || exit 1
        build || exit 1
    else
        exit 1
    fi
fi

MTP="$(find examples/pyengine -name '*.mtp' | head -1)"
[ -n "$MTP" ] || { echo "::error::после сборки нет .mtp"; exit 1; }
mkdir -p "$ROOT/out"
cp "$MTP" "$ROOT/out/margyt.pyengine.mtp"
echo "готово: $(ls -la "$ROOT/out/margyt.pyengine.mtp")"
unzip -l "$ROOT/out/margyt.pyengine.mtp"
