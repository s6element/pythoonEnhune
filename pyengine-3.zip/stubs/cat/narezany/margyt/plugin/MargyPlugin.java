package cat.narezany.margyt.plugin;

// заглушка только для компиляции, в dex не попадает (настоящий класс уже в апке)
public abstract class MargyPlugin {
    public static final int API = 1;
    public void onStart(android.content.Context c) {}
    public void onActivityCreated(android.app.Activity a) {}
    public void onActivityResumed(android.app.Activity a) {}
    public void onActivityPaused(android.app.Activity a) {}
    public int onColour(int c) { return c; }
    public String onRegion(String key, String value) { return value; }
    public void onStop() {}
}
