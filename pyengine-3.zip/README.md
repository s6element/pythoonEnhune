# pyengine для MargyT

`.mtp`-плагин, который поднимает внутри TikTok питон и грузит `.plugin`-файлы без компиляции.

## Как получить .mtp через GitHub (с телефона)

1. Создай репо (можно приватное).
2. Add file -> Upload files: загрузи `pyengine.zip` целиком (распаковывать не надо).
3. Add file -> Create new file, имя `.github/workflows/build.yml`, вставь содержимое `build.yml` (18 строк), Commit.
4. Actions -> build -> Run workflow. Галку `full` пока не трогай (см. ниже).
5. Когда пройдёт, внизу страницы запуска, в Artifacts, `pyengine-mtp`. Скачай, достань `margyt.pyengine.mtp`, ставь в MargyT -> Plugins.

Если тулчейн сломан (issue #3 narezany/MargyT: api не компилится), `scripts/build_mtp.sh` сам применяет патч из issue и пробует снова.
Если `narezany/MargyT` удалён, в Run workflow впиши в поле `toolchain` живой форк. Вся логика в `scripts/ci.sh`.

## Две ступеньки

- **full выключен**: в `.mtp` только Java. Движок при старте пишет в журнал мода папку плагина и список файлов в ней,
  а на первом экране имя активити. Этого хватит, чтобы понять, грузит ли MargyT плагин и правильно ли я угадал `margyt().folder()/log()`.
- **full включён**: к ним добавляются libpython 3.14, stdlib, sdk, `libpyjni.so` (собирается NDK на раннере) и `bundled/*.plugin`.
  Если всё взлетит, при первом экране появится тост "python жив".

Сначала запускай без full. Если в журнале появилась строка `pyengine: onStart ok ...`, включай full.

## Что внутри

    plugin/            manifest.json + java/ (то, что собирает тулчейн MargyT)
    native/pyjni.c     JNI-прослойка к CPython
    py/                SDK: java.py, android_utils.py, base_plugin.py, _engine.py
    bundled/           .plugin-файлы, которые зашиваются в .mtp
    scripts/           build_mtp.sh, assemble_full.sh, patch_issue3.py
    tests/             хост-хост-тесты моста (гоняются в Actions сами, упавший тест сборку не останавливает)

## Статус

Проверено на ПК: Java-мост, питоновский SDK, загрузчик `.plugin`, C-прослойка с настоящим CPython (JNI подделан).
Не проверено: запуск в TikTok, `build_mtp.sh` и `assemble_full.sh` на раннере GitHub, раскладка архива python.org.

## Формат .plugin

Один `.py` в стиле exteraGram: `__id__`, `__name__`, `__description__`, `__author__`, `__version__` и класс-наследник `BasePlugin`.
Движок ищет их в `<files>/pyplugins/`, `Android/data/<пакет>/files/pyplugins/` и в папке самого плагина (сюда попадает `bundled/`).
См. `bundled/hello.plugin`.

## Ограничения v1

- `onColour` в питон не пробрасывается (горячий путь отрисовки).
- Хуков на методы TikTok нет, exteraGram-API (`hook_method`) не работает.
- Массивы: только чтение и длина. Varargs не поддерживаются.
- Песочницы нет.
