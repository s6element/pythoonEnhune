/* JNI-прослойка: поднимает CPython внутри процесса и гоняет строки между Java и Python.
 * Python -> Java: модуль _mt, функция call(op, target, name, args) -> str
 * Java -> Python: Bridge.nDispatch(name, args) -> _engine.dispatch
 */
#include <jni.h>
#include <Python.h>
#include <stdlib.h>
#include <string.h>

static JavaVM *g_vm;
static jclass g_bridge;
static jmethodID g_call;
static PyObject *g_engine;
static int g_ready;

JNIEXPORT jint JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void)reserved;
    g_vm = vm;
    return JNI_VERSION_1_6;
}

static JNIEnv *get_env(void) {
    JNIEnv *env = NULL;
    if ((*g_vm)->GetEnv(g_vm, (void **)&env, JNI_VERSION_1_6) == JNI_OK) return env;
    if ((*g_vm)->AttachCurrentThread(g_vm, &env, NULL) == JNI_OK) return env;
    return NULL;
}

static PyObject *mt_call(PyObject *self, PyObject *args) {
    const char *op, *target, *name, *a;
    char *res = NULL;
    (void)self;
    if (!PyArg_ParseTuple(args, "ssss", &op, &target, &name, &a)) return NULL;

    Py_BEGIN_ALLOW_THREADS
    JNIEnv *env = get_env();
    if (env) {
        jstring jo = (*env)->NewStringUTF(env, op);
        jstring jt = (*env)->NewStringUTF(env, target);
        jstring jn = (*env)->NewStringUTF(env, name);
        jstring ja = (*env)->NewStringUTF(env, a);
        jstring r = (jstring)(*env)->CallStaticObjectMethod(env, g_bridge, g_call, jo, jt, jn, ja);
        if ((*env)->ExceptionCheck(env)) {
            (*env)->ExceptionClear(env);
            res = strdup("e:java%20exception%20in%20bridge");
        } else if (r) {
            const char *u = (*env)->GetStringUTFChars(env, r, NULL);
            if (u) {
                res = strdup(u);
                (*env)->ReleaseStringUTFChars(env, r, u);
            }
        }
        (*env)->DeleteLocalRef(env, jo);
        (*env)->DeleteLocalRef(env, jt);
        (*env)->DeleteLocalRef(env, jn);
        (*env)->DeleteLocalRef(env, ja);
        if (r) (*env)->DeleteLocalRef(env, r);
    }
    Py_END_ALLOW_THREADS

    if (!res) {
        PyErr_SetString(PyExc_RuntimeError, "jni call failed");
        return NULL;
    }
    PyObject *o = PyUnicode_FromString(res);
    free(res);
    return o;
}

static PyMethodDef mt_methods[] = {
    {"call", mt_call, METH_VARARGS, NULL},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef mt_module = {
    PyModuleDef_HEAD_INIT, "_mt", NULL, -1, mt_methods, NULL, NULL, NULL, NULL
};

static PyObject *PyInit__mt(void) { return PyModule_Create(&mt_module); }

static wchar_t *widen(const char *s) {
    /* пути у нас ascii */
    size_t n = strlen(s);
    wchar_t *w = (wchar_t *)malloc((n + 1) * sizeof(wchar_t));
    for (size_t i = 0; i <= n; i++) w[i] = (wchar_t)(unsigned char)s[i];
    return w;
}

static int add_path(PyConfig *cfg, const char *p) {
    wchar_t *w = widen(p);
    PyStatus st = PyWideStringList_Append(&cfg->module_search_paths, w);
    free(w);
    return PyStatus_Exception(st) ? -1 : 0;
}

JNIEXPORT void JNICALL Java_cat_pyengine_Bridge_nInit(JNIEnv *env, jclass cls,
        jstring jstd, jstring jsdk, jstring jext) {
    if (g_ready) return;
    g_bridge = (jclass)(*env)->NewGlobalRef(env, cls);
    g_call = (*env)->GetStaticMethodID(env, cls, "call",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
    if (!g_call) return;

    const char *std = (*env)->GetStringUTFChars(env, jstd, NULL);
    const char *sdk = (*env)->GetStringUTFChars(env, jsdk, NULL);
    const char *ext = (*env)->GetStringUTFChars(env, jext, NULL);

    PyImport_AppendInittab("_mt", PyInit__mt);

    PyConfig cfg;
    PyConfig_InitIsolatedConfig(&cfg);
    cfg.install_signal_handlers = 0;
    cfg.site_import = 0;
    cfg.pathconfig_warnings = 0;
    cfg.module_search_paths_set = 1;
    int bad = add_path(&cfg, std) || add_path(&cfg, sdk) || add_path(&cfg, ext);

    PyStatus st = bad ? PyStatus_Error("path setup") : Py_InitializeFromConfig(&cfg);
    PyConfig_Clear(&cfg);
    (*env)->ReleaseStringUTFChars(env, jstd, std);
    (*env)->ReleaseStringUTFChars(env, jsdk, sdk);
    (*env)->ReleaseStringUTFChars(env, jext, ext);
    if (PyStatus_Exception(st)) return;

    g_engine = PyImport_ImportModule("_engine");
    if (!g_engine) {
        PyErr_Print();
    } else {
        PyObject *r = PyObject_CallMethod(g_engine, "start", NULL);
        if (!r) PyErr_Print(); else Py_DECREF(r);
        g_ready = 1;
    }
    PyEval_SaveThread(); /* отпускаем GIL, дальше все заходят через PyGILState */
}

JNIEXPORT jstring JNICALL Java_cat_pyengine_Bridge_nDispatch(JNIEnv *env, jclass cls,
        jstring jname, jstring jargs) {
    (void)cls;
    if (!g_ready) return NULL;
    const char *n = (*env)->GetStringUTFChars(env, jname, NULL);
    const char *a = (*env)->GetStringUTFChars(env, jargs, NULL);
    jstring out = NULL;

    PyGILState_STATE gs = PyGILState_Ensure();
    PyObject *r = PyObject_CallMethod(g_engine, "dispatch", "ss", n, a);
    if (!r) {
        PyErr_Print();
    } else {
        if (PyUnicode_Check(r)) {
            const char *u = PyUnicode_AsUTF8(r);
            if (u) out = (*env)->NewStringUTF(env, u);
        }
        Py_DECREF(r);
    }
    PyGILState_Release(gs);

    (*env)->ReleaseStringUTFChars(env, jname, n);
    (*env)->ReleaseStringUTFChars(env, jargs, a);
    return out;
}
