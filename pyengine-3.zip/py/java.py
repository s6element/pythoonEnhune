"""Мост Python <-> Java. Всё поверх одной функции _mt.call(op, target, name, args)."""
import collections
import traceback
from urllib.parse import quote, unquote

import _mt


class JavaError(Exception):
    pass


def _q(s):
    return quote(s, safe="")


def _pack(v):
    if v is None:
        return "n:"
    if v is True:
        return "z:1"
    if v is False:
        return "z:0"
    if isinstance(v, int):
        return "l:%d" % v
    if isinstance(v, float):
        return "d:%r" % v
    if isinstance(v, str):
        return "s:" + _q(v)
    h = getattr(v, "_h", None)
    if h is not None:
        return "h:%d" % h
    raise TypeError("не могу передать %s в java" % type(v).__name__)


def _unpack(r):
    tag, _, rest = r.partition(":")
    if tag == "v":
        return None
    if tag == "z":
        return rest == "1"
    if tag == "l":
        return int(rest)
    if tag == "d":
        return float(rest)
    if tag == "s":
        return unquote(rest)
    if tag == "h":
        hid, _, cn = rest.partition(":")
        return JObject(int(hid), cn)
    if tag == "e":
        raise JavaError(unquote(rest))
    raise RuntimeError("кривой ответ моста: " + r)


def call(op, target="", name="", *args):
    return _unpack(_mt.call(op, str(target), name, ",".join([_pack(a) for a in args])))


def _log(msg):
    try:
        _mt.call("log", "", "", "s:" + _q(str(msg)))
    except Exception:
        pass


def app_context():
    return call("app")


_kinds = {}


def _kind(owner, name, static, target):
    key = (owner, name, static)
    k = _kinds.get(key)
    if k is None:
        k = call("skind" if static else "kind", target, name)
        _kinds[key] = k
    return k


class _Method:
    __slots__ = ("_o", "_n", "_s")

    def __init__(self, owner, name, static):
        # держим сам JObject, иначе временный объект умрёт и хэндл освободится до вызова
        self._o, self._n, self._s = owner, name, static

    def __call__(self, *args):
        if self._s:
            return call("scall", self._o, self._n, *args)
        return call("call", self._o._h, self._n, *args)


class JObject:
    __slots__ = ("_h", "_cn")

    def __init__(self, h, cn):
        object.__setattr__(self, "_h", h)
        object.__setattr__(self, "_cn", cn)

    def __del__(self):
        try:
            _mt.call("free", str(self._h), "", "")
        except Exception:
            pass

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        k = _kind(self._cn, name, False, self._h)
        if k == "f":
            return call("get", self._h, name)
        if k == "m":
            return _Method(self, name, False)
        raise AttributeError("%s: нет члена %s" % (self._cn, name))

    def __setattr__(self, name, value):
        call("set", self._h, name, value)

    def __str__(self):
        return call("call", self._h, "toString")

    def __repr__(self):
        return "<java %s #%d>" % (self._cn, self._h)

    def __eq__(self, other):
        return bool(call("call", self._h, "equals", other))

    def __hash__(self):
        return call("call", self._h, "hashCode")

    def __len__(self):
        return call("alen", self._h)

    def __getitem__(self, i):
        return call("aget", self._h, "", i)

    def __iter__(self):
        for i in range(len(self)):
            yield self[i]


class JClass:
    def __init__(self, name):
        object.__setattr__(self, "_n", name)
        object.__setattr__(self, "_cls", None)

    @property
    def _h(self):
        if self._cls is None:
            object.__setattr__(self, "_cls", call("forname", self._n))
        return self._cls._h

    def __call__(self, *args):
        return call("new", self._n, "", *args)

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        k = _kind(self._n, name, True, self._n)
        if k == "f":
            return call("sget", self._n, name)
        if k == "m":
            return _Method(self._n, name, True)
        if k == "c":
            return JClass(self._n + "$" + name)
        raise AttributeError("%s: нет члена %s" % (self._n, name))

    def __setattr__(self, name, value):
        call("sset", self._n, name, value)

    def __repr__(self):
        return "<jclass %s>" % self._n


_classes = {}


def jclass(name):
    c = _classes.get(name)
    if c is None:
        call("findclass", name)
        c = _classes[name] = JClass(name)
    return c


# ---- колбэки ----

_proxies = {}
_next = [0]
_keep = collections.deque(maxlen=64)


def _packret(r):
    if r is None:
        return "v:"
    s = _pack(r)
    if s.startswith("h:"):
        _keep.append(r)
    return s


def _callback(args):
    cid, meth, rest = args.split(";", 2)
    obj = _proxies.get(int(cid))
    if obj is None:
        return "v:"
    fn = getattr(obj, meth, None)
    if fn is None:
        return "v:"
    try:
        vals = [_unpack(x) for x in rest.split(",")] if rest else []
        return _packret(fn(*vals))
    except Exception:
        _log("callback %s.%s:\n%s" % (type(obj).__name__, meth, traceback.format_exc()))
        return "v:"


def dynamic_proxy(*ifaces):
    names = [i._n if isinstance(i, JClass) else i for i in ifaces]

    class Proxy:
        _ifaces = names

        def __new__(cls, *a, **k):
            self = object.__new__(cls)
            _next[0] += 1
            self._pid = _next[0]
            _proxies[self._pid] = self
            self._jo = call("proxy", ",".join(names), str(self._pid))
            return self

        @property
        def _h(self):
            return self._jo._h

        def release(self):
            _proxies.pop(self._pid, None)

    return Proxy
