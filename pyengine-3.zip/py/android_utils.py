import traceback

import java
from java import jclass, dynamic_proxy


def log(*args):
    java._log(" ".join(str(a) for a in args))


def get_context():
    return java.app_context()


def run_on_ui_thread(fn, delay=0):
    Looper = jclass("android.os.Looper")
    main = Looper.getMainLooper()
    if not delay and main.isCurrentThread():
        fn()
        return

    class _R(dynamic_proxy(jclass("java.lang.Runnable"))):
        def run(self):
            try:
                fn()
            except Exception:
                log("run_on_ui_thread:\n" + traceback.format_exc())
            finally:
                self.release()

    h = jclass("android.os.Handler")(main)
    r = _R()
    if delay:
        h.postDelayed(r, int(delay))
    else:
        h.post(r)
