import ast
import os
import re
import sys
import time
import traceback
import types

import java
from base_plugin import BasePlugin

FAILS = 5
SCAN_EVERY = 3.0
_META = ("__id__", "__name__", "__description__", "__author__", "__version__",
         "__min_version__", "__icon__")

_dirs = []
_loaded = {}
_last_scan = 0.0
_stopped = False


class _E:
    def __init__(self, mtime):
        self.mtime = mtime
        self.plugin = None
        self.mod = None
        self.fails = 0


def log(*a):
    java._log(" ".join(str(x) for x in a))


def start():
    ctx = java.app_context()
    files = ctx.getFilesDir().getAbsolutePath()
    _dirs.append(os.path.join(files, "pyplugins"))
    ext = ctx.getExternalFilesDir(None)
    if ext is not None:
        _dirs.append(os.path.join(ext.getAbsolutePath(), "pyplugins"))
    for d in _dirs:
        try:
            os.makedirs(d, exist_ok=True)
        except OSError:
            pass
    _dirs.append(java.call("folder"))
    log("pyengine: python %s, папки: %s" % (sys.version.split()[0], ", ".join(_dirs)))
    _scan()


def _scan():
    seen = {}
    for d in _dirs:
        try:
            names = os.listdir(d)
        except OSError:
            continue
        for n in names:
            if n.endswith(".plugin"):
                p = os.path.join(d, n)
                try:
                    seen[p] = os.stat(p).st_mtime_ns
                except OSError:
                    pass
    for p in list(_loaded):
        if p not in seen or _loaded[p].mtime != seen[p]:
            _unload(p)
    for p, m in seen.items():
        if p not in _loaded:
            _load(p, m)


def _load(path, mtime):
    e = _E(mtime)
    _loaded[path] = e
    try:
        with open(path, encoding="utf-8") as f:
            src = f.read()
        tree = ast.parse(src, path)
        meta, body = {}, []
        for node in tree.body:
            if (isinstance(node, ast.Assign) and len(node.targets) == 1
                    and isinstance(node.targets[0], ast.Name) and node.targets[0].id in _META):
                try:
                    meta[node.targets[0].id.strip("_")] = ast.literal_eval(node.value)
                except Exception:
                    pass
                if node.targets[0].id == "__name__":
                    continue  # иначе у модуля подменится __name__ и сломаются dataclasses и т.п.
            body.append(node)
        tree.body = body
        pid = str(meta.get("id") or os.path.basename(path)[:-len(".plugin")])
        modname = "pyplugin_" + re.sub(r"\W", "_", pid)
        mod = types.ModuleType(modname)
        mod.__file__ = path
        sys.modules[modname] = mod
        e.mod = modname
        exec(compile(tree, path, "exec"), mod.__dict__)
        cls = None
        for v in list(mod.__dict__.values()):
            if (isinstance(v, type) and issubclass(v, BasePlugin) and v is not BasePlugin
                    and v.__module__ == modname):
                cls = v
                break
        if cls is None:
            raise RuntimeError("в файле нет класса-наследника BasePlugin")
        p = cls()
        p.id, p.name, p.meta, p.path = pid, str(meta.get("name", pid)), meta, path
        p.on_plugin_load()
        e.plugin = p
        p.on_start(java.app_context())
        log("pyengine: загружен %s %s" % (pid, meta.get("version", "")))
    except Exception:
        log("pyengine: не загрузился %s\n%s" % (path, traceback.format_exc()))
        e.plugin = None


def _unload(path):
    e = _loaded.pop(path, None)
    if e is None:
        return
    _drop(e)


def _drop(e):
    p, e.plugin = e.plugin, None
    if p is not None:
        try:
            p.on_plugin_unload()
        except Exception:
            log("pyengine: unload %s\n%s" % (p.id, traceback.format_exc()))
    if e.mod:
        sys.modules.pop(e.mod, None)


def _fail(e, where):
    e.fails += 1
    pid = e.plugin.id if e.plugin else "?"
    log("[%s] %s\n%s" % (pid, where, traceback.format_exc()))
    if e.fails >= FAILS:
        log("pyengine: %s выключен до перезапуска (слишком много ошибок)" % pid)
        _drop(e)


def _each(method, *args):
    for e in list(_loaded.values()):
        p = e.plugin
        if p is None:
            continue
        try:
            getattr(p, method)(*args)
        except Exception:
            _fail(e, method)


_HOOKS = {"created": "on_activity_created", "resumed": "on_activity_resumed",
          "paused": "on_activity_paused"}


def dispatch(name, args):
    global _last_scan, _stopped
    try:
        if name == "cb":
            return java._callback(args)
        if _stopped:
            return "v:"
        vals = [java._unpack(x) for x in args.split(",")] if args else []
        if name == "stop":
            _stopped = True
            for p in list(_loaded):
                _unload(p)
            return "v:"
        if name == "region":
            key, value = vals
            for e in list(_loaded.values()):
                if e.plugin is None:
                    continue
                try:
                    r = e.plugin.on_region(key, value)
                    if isinstance(r, str):
                        value = r
                except Exception:
                    _fail(e, "on_region")
            return "s:" + java._q(value)
        if name == "resumed":
            now = time.monotonic()
            if now - _last_scan > SCAN_EVERY:
                _last_scan = now
                _scan()
        hook = _HOOKS.get(name)
        if hook:
            _each(hook, *vals)
    except Exception:
        log("pyengine: dispatch %s\n%s" % (name, traceback.format_exc()))
    return "v:"
