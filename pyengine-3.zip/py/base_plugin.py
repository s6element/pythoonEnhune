import json

import java


class BasePlugin:
    # id/name/meta/path выставляет движок после загрузки
    id = ""
    name = ""
    meta = {}
    path = ""

    def on_plugin_load(self):
        pass

    def on_plugin_unload(self):
        pass

    def on_start(self, context):
        pass

    def on_activity_created(self, activity):
        pass

    def on_activity_resumed(self, activity):
        pass

    def on_activity_paused(self, activity):
        pass

    def on_region(self, key, value):
        return value

    def log(self, *args):
        java._log("[%s] %s" % (self.id, " ".join(str(a) for a in args)))

    def get_context(self):
        return java.app_context()

    def _prefs(self):
        return java.app_context().getSharedPreferences("pyplugin_" + self.id, 0)

    def get_setting(self, key, default=None):
        raw = self._prefs().getString(key, None)
        if raw is None:
            return default
        try:
            return json.loads(raw)
        except ValueError:
            return default

    def set_setting(self, key, value):
        self._prefs().edit().putString(key, json.dumps(value)).apply()
