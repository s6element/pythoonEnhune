package cat.pyengine;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/** Java-сторона моста. Всё ходит строками: op, target, name, args -> результат. */
public final class Bridge {
    public interface Logger { void log(String s); }
    public interface Dispatcher { String dispatch(String name, String args); }

    public static volatile Logger logger;
    public static volatile Object appContext;
    public static volatile String folder = "";
    public static volatile Dispatcher dispatcher = new Dispatcher() {
        public String dispatch(String n, String a) { return nDispatch(n, a); }
    };

    private static final ConcurrentHashMap<Integer, Object> H = new ConcurrentHashMap<Integer, Object>();
    private static final AtomicInteger N = new AtomicInteger(1);

    public static native void nInit(String stdlibZip, String sdkZip, String extDir);
    public static native String nDispatch(String name, String args);

    private Bridge() {}

    static ClassLoader loader() {
        ClassLoader l = Bridge.class.getClassLoader();
        return l != null ? l : ClassLoader.getSystemClassLoader();
    }

    public static int put(Object o) {
        int id = N.getAndIncrement();
        H.put(id, o);
        return id;
    }

    public static String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8").replace("+", "%20"); }
        catch (UnsupportedEncodingException e) { throw new RuntimeException(e); }
    }

    public static String dec(String s) {
        try { return URLDecoder.decode(s, "UTF-8"); }
        catch (UnsupportedEncodingException e) { throw new RuntimeException(e); }
    }

    public static String ret(Object o) {
        if (o == null) return "v:";
        if (o instanceof Boolean) return "z:" + (((Boolean) o) ? "1" : "0");
        if (o instanceof Byte || o instanceof Short || o instanceof Integer || o instanceof Long) return "l:" + o;
        if (o instanceof Float || o instanceof Double) return "d:" + o;
        if (o instanceof Character || o instanceof String) return "s:" + enc(o.toString());
        return "h:" + put(o) + ":" + o.getClass().getName();
    }

    static String err(Throwable t) {
        return "e:" + enc(t.getClass().getName() + ": " + t.getMessage());
    }

    /** точка входа из C */
    public static String call(String op, String target, String name, String args) {
        try {
            return run(op, target, name, parse(args));
        } catch (InvocationTargetException e) {
            return err(e.getCause() != null ? e.getCause() : e);
        } catch (Throwable t) {
            return err(t);
        }
    }

    static Object obj(String target) {
        Object o = H.get(Integer.valueOf(target));
        if (o == null) throw new IllegalStateException("stale handle " + target);
        return o;
    }

    static Object[] parse(String s) {
        if (s == null || s.length() == 0) return new Object[0];
        String[] parts = s.split(",", -1);
        Object[] out = new Object[parts.length];
        for (int i = 0; i < parts.length; i++) {
            String p = parts[i];
            int c = p.indexOf(':');
            String v = p.substring(c + 1);
            switch (p.charAt(0)) {
                case 'n': out[i] = null; break;
                case 'z': out[i] = Boolean.valueOf(v.equals("1")); break;
                case 'l': out[i] = Long.valueOf(v); break;
                case 'd': out[i] = Double.valueOf(v); break;
                case 's': out[i] = dec(v); break;
                case 'h': {
                    int k = v.indexOf(':');
                    out[i] = obj(k >= 0 ? v.substring(0, k) : v);
                    break;
                }
                default: throw new IllegalArgumentException("bad arg " + p);
            }
        }
        return out;
    }

    static Class<?> forName(String n) throws ClassNotFoundException {
        return Class.forName(n, false, loader());
    }

    private static String run(String op, String target, String name, Object[] a) throws Throwable {
        switch (op) {
            case "findclass": return "s:" + enc(forName(target).getName());
            case "forname": return ret(forName(target));
            case "new": {
                Constructor<?> k = pickCtor(forName(target), a);
                return ret(k.newInstance(conv(k.getParameterTypes(), a)));
            }
            case "scall": {
                Method m = pick(forName(target), name, a, true);
                return ret(m.invoke(null, conv(m.getParameterTypes(), a)));
            }
            case "call": {
                Object o = obj(target);
                Method m = pick(o.getClass(), name, a, false);
                return ret(m.invoke(o, conv(m.getParameterTypes(), a)));
            }
            case "get": {
                Object o = obj(target);
                if (o.getClass().isArray() && name.equals("length")) return ret(Array.getLength(o));
                return ret(field(o.getClass(), name).get(o));
            }
            case "set": {
                Object o = obj(target);
                Field f = field(o.getClass(), name);
                f.set(o, conv1(f.getType(), a[0]));
                return "v:";
            }
            case "sget": return ret(field(forName(target), name).get(null));
            case "sset": {
                Field f = field(forName(target), name);
                f.set(null, conv1(f.getType(), a[0]));
                return "v:";
            }
            case "kind": return "s:" + kind(obj(target).getClass(), name, false);
            case "skind": return "s:" + kind(forName(target), name, true);
            case "alen": return ret(Array.getLength(obj(target)));
            case "aget": return ret(Array.get(obj(target), ((Long) a[0]).intValue()));
            case "aset": {
                Object arr = obj(target);
                Array.set(arr, ((Long) a[0]).intValue(), conv1(arr.getClass().getComponentType(), a[1]));
                return "v:";
            }
            case "proxy": {
                String[] ns = target.split(",");
                Class<?>[] ifs = new Class<?>[ns.length];
                for (int i = 0; i < ns.length; i++) ifs[i] = forName(ns[i]);
                return ret(Proxy.newProxyInstance(loader(), ifs, new PyHandler(Integer.parseInt(name))));
            }
            case "free": H.remove(Integer.valueOf(target)); return "v:";
            case "app": return ret(appContext);
            case "folder": return "s:" + enc(folder);
            case "log": {
                Logger l = logger;
                if (l != null) l.log(String.valueOf(a[0]));
                return "v:";
            }
            default: throw new IllegalArgumentException("unknown op " + op);
        }
    }

    // ---- поиск членов ----

    static String kind(Class<?> c, String name, boolean isStatic) {
        if (c.isArray() && name.equals("length")) return "f";
        for (Method m : c.getMethods()) if (m.getName().equals(name)) return "m";
        for (Field f : c.getFields()) if (f.getName().equals(name)) return "f";
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            for (Method m : k.getDeclaredMethods()) if (m.getName().equals(name)) return "m";
            for (Field f : k.getDeclaredFields()) if (f.getName().equals(name)) return "f";
        }
        if (isStatic) {
            try { forName(c.getName() + "$" + name); return "c"; } catch (ClassNotFoundException ignored) {}
        }
        return "n";
    }

    static Field field(Class<?> c, String name) throws NoSuchFieldException {
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            try {
                Field f = k.getDeclaredField(name);
                try { f.setAccessible(true); } catch (Throwable ignored) {}
                return f;
            } catch (NoSuchFieldException ignored) {}
        }
        return c.getField(name);
    }

    static Method pick(Class<?> c, String name, Object[] a, boolean wantStatic) throws NoSuchMethodException {
        Method best = null;
        int bestScore = Integer.MAX_VALUE;
        ArrayList<Method> all = new ArrayList<Method>();
        for (Method m : c.getMethods()) all.add(m);
        for (Class<?> k = c; k != null; k = k.getSuperclass())
            for (Method m : k.getDeclaredMethods()) all.add(m);
        for (Method m : all) {
            if (!m.getName().equals(name)) continue;
            if (wantStatic && !Modifier.isStatic(m.getModifiers())) continue;
            int s = score(m.getParameterTypes(), a);
            if (s >= 0 && s < bestScore) { best = m; bestScore = s; }
        }
        if (best == null) throw new NoSuchMethodException(c.getName() + "." + name + "/" + a.length);
        try { best.setAccessible(true); } catch (Throwable ignored) {}
        return best;
    }

    static Constructor<?> pickCtor(Class<?> c, Object[] a) throws NoSuchMethodException {
        Constructor<?> best = null;
        int bestScore = Integer.MAX_VALUE;
        ArrayList<Constructor<?>> all = new ArrayList<Constructor<?>>();
        for (Constructor<?> k : c.getConstructors()) all.add(k);
        for (Constructor<?> k : c.getDeclaredConstructors()) all.add(k);
        for (Constructor<?> k : all) {
            int s = score(k.getParameterTypes(), a);
            if (s >= 0 && s < bestScore) { best = k; bestScore = s; }
        }
        if (best == null) throw new NoSuchMethodException(c.getName() + ".<init>/" + a.length);
        try { best.setAccessible(true); } catch (Throwable ignored) {}
        return best;
    }

    static int score(Class<?>[] ps, Object[] a) {
        if (ps.length != a.length) return -1;
        int total = 0;
        for (int i = 0; i < ps.length; i++) {
            int s = compat(ps[i], a[i]);
            if (s < 0) return -1;
            total += s;
        }
        return total;
    }

    static int compat(Class<?> p, Object a) {
        if (a == null) return p.isPrimitive() ? -1 : 1;
        if (a instanceof String) {
            if (p == String.class) return 0;
            if (p == CharSequence.class || p == Object.class) return 1;
            if ((p == char.class || p == Character.class) && ((String) a).length() == 1) return 2;
            return -1;
        }
        if (a instanceof Boolean) {
            if (p == boolean.class || p == Boolean.class) return 0;
            return p == Object.class ? 1 : -1;
        }
        if (a instanceof Long) {
            if (p == long.class || p == Long.class) return 0;
            if (p == int.class || p == Integer.class) return 1;
            if (p == short.class || p == Short.class || p == byte.class || p == Byte.class) return 2;
            if (p == double.class || p == Double.class || p == float.class || p == Float.class) return 3;
            if (p == Number.class || p == Object.class) return 3;
            return -1;
        }
        if (a instanceof Double) {
            if (p == double.class || p == Double.class) return 0;
            if (p == float.class || p == Float.class) return 1;
            if (p == Number.class || p == Object.class) return 2;
            return -1;
        }
        if (p.isPrimitive()) return -1;
        if (!p.isInstance(a)) return -1;
        return p == a.getClass() ? 0 : 1;
    }

    static Object[] conv(Class<?>[] ps, Object[] a) {
        Object[] out = new Object[a.length];
        for (int i = 0; i < a.length; i++) out[i] = conv1(ps[i], a[i]);
        return out;
    }

    static Object conv1(Class<?> p, Object a) {
        if (a == null) return null;
        if (p == int.class || p == Integer.class) return Integer.valueOf(((Number) a).intValue());
        if (p == long.class || p == Long.class) return Long.valueOf(((Number) a).longValue());
        if (p == short.class || p == Short.class) return Short.valueOf(((Number) a).shortValue());
        if (p == byte.class || p == Byte.class) return Byte.valueOf(((Number) a).byteValue());
        if (p == float.class || p == Float.class) return Float.valueOf(((Number) a).floatValue());
        if (p == double.class || p == Double.class) return Double.valueOf(((Number) a).doubleValue());
        if (p == char.class || p == Character.class) return Character.valueOf(((String) a).charAt(0));
        return a;
    }

    // ---- колбэки Java -> Python ----

    static final class PyHandler implements InvocationHandler {
        private final int id;
        PyHandler(int id) { this.id = id; }

        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            String m = method.getName();
            if (method.getDeclaringClass() == Object.class) {
                if (m.equals("equals")) return Boolean.valueOf(proxy == args[0]);
                if (m.equals("hashCode")) return Integer.valueOf(System.identityHashCode(proxy));
                return "PyProxy#" + id;
            }
            StringBuilder sb = new StringBuilder();
            if (args != null) {
                for (int i = 0; i < args.length; i++) {
                    if (i > 0) sb.append(',');
                    sb.append(args[i] == null ? "n:" : ret(args[i]));
                }
            }
            String r = dispatcher.dispatch("cb", id + ";" + m + ";" + sb);
            return decodeReturn(method.getReturnType(), r);
        }
    }

    static Object decodeReturn(Class<?> rt, String r) {
        if (rt == void.class) return null;
        if (r == null || r.length() < 2 || r.charAt(0) == 'v' || r.charAt(0) == 'n') return zero(rt);
        String v = r.substring(2);
        switch (r.charAt(0)) {
            case 'h': {
                int k = v.indexOf(':');
                return obj(k >= 0 ? v.substring(0, k) : v);
            }
            case 'z': return conv1(rt, Boolean.valueOf(v.equals("1")));
            case 'l': return conv1(rt, Long.valueOf(v));
            case 'd': return conv1(rt, Double.valueOf(v));
            case 's': return conv1(rt, dec(v));
            default: return zero(rt);
        }
    }

    static Object zero(Class<?> rt) {
        if (!rt.isPrimitive()) return null;
        if (rt == boolean.class) return Boolean.FALSE;
        if (rt == char.class) return Character.valueOf('\0');
        return conv1(rt, Long.valueOf(0));
    }
}
