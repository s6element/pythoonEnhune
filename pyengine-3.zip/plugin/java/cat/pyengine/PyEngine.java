package cat.pyengine;

import android.app.Activity;
import android.content.Context;
import cat.narezany.margyt.plugin.MargyPlugin;
import java.io.File;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;

public final class PyEngine extends MargyPlugin {
    private volatile boolean ready;
    private volatile boolean stopped;
    private volatile boolean diagLogged;
    private volatile WeakReference<Activity> lastResumed;
    private String dir = "";

    @Override
    public void onStart(Context context) {
        Bridge.appContext = context;
        Bridge.logger = new Bridge.Logger() {
            public void log(String s) { say(s); }
        };
        try {
            dir = String.valueOf(pc("folder"));
        } catch (Throwable t) {
            return;
        }
        Bridge.folder = dir;
        say("pyengine: onStart ok, folder=" + dir + ", files=" + names(dir));
        Thread t = new Thread(new Runnable() {
            public void run() { boot(); }
        }, "pyengine-init");
        t.setDaemon(true);
        t.start();
    }

    private void boot() {
        try {
            File d = new File(dir);
            File[] files = d.listFiles();
            if (files != null) {
                for (File f : files) {
                    String n = f.getName();
                    if (n.startsWith("libpython3") && n.endsWith(".so")) System.load(f.getAbsolutePath());
                }
            }
            if (!new File(d, "libpyjni.so").exists()) {
                say("pyengine: libpyjni.so нет в папке плагина, режим диагностики (питон не запускается)");
                return;
            }
            System.load(new File(d, "libpyjni.so").getAbsolutePath());
            Bridge.nInit(new File(d, "stdlib.zip").getAbsolutePath(),
                         new File(d, "sdk.zip").getAbsolutePath(),
                         d.getAbsolutePath());
            ready = true;
            WeakReference<Activity> w = lastResumed;
            Activity a = w == null ? null : w.get();
            if (a != null) post("resumed", a);
        } catch (Throwable t) {
            say("pyengine: init failed: " + t);
        }
    }

    @Override public void onActivityCreated(Activity a) { post("created", a); }

    @Override
    public void onActivityResumed(Activity a) {
        lastResumed = new WeakReference<Activity>(a);
        if (!ready && !diagLogged && a != null) {
            diagLogged = true;
            say("pyengine: первый onActivityResumed: " + a.getClass().getName());
        }
        post("resumed", a);
    }

    @Override public void onActivityPaused(Activity a) { post("paused", a); }

    @Override
    public String onRegion(String key, String value) {
        if (!ready || stopped) return value;
        try {
            String r = Bridge.nDispatch("region", "s:" + Bridge.enc(key) + ",s:" + Bridge.enc(value));
            if (r != null && r.startsWith("s:")) return Bridge.dec(r.substring(2));
        } catch (Throwable t) {
            say("pyengine: region: " + t);
        }
        return value;
    }

    @Override
    public void onStop() {
        if (!ready || stopped) return;
        stopped = true;
        try { Bridge.nDispatch("stop", ""); } catch (Throwable ignored) {}
    }

    private void post(String name, Activity a) {
        if (!ready || stopped || a == null) return;
        try {
            Bridge.nDispatch(name, Bridge.ret(a));
        } catch (Throwable t) {
            say("pyengine: " + name + ": " + t);
        }
    }

    // margyt() / PluginContext зовём рефлексией: точные сигнатуры в доках не расписаны
    private Object pc(String name, Object... args) throws Exception {
        Method m0 = find(getClass(), "margyt", 0);
        m0.setAccessible(true);
        Object ctx = m0.invoke(this);
        Method m = find(ctx.getClass(), name, args.length);
        m.setAccessible(true);
        return m.invoke(ctx, args);
    }

    private static Method find(Class<?> c, String name, int argc) throws NoSuchMethodException {
        for (Method m : c.getMethods())
            if (m.getName().equals(name) && m.getParameterTypes().length == argc) return m;
        for (Class<?> k = c; k != null; k = k.getSuperclass())
            for (Method m : k.getDeclaredMethods())
                if (m.getName().equals(name) && m.getParameterTypes().length == argc) return m;
        throw new NoSuchMethodException(name);
    }

    private static String names(String dir) {
        String[] l = new File(dir).list();
        if (l == null) return "[нет доступа]";
        java.util.Arrays.sort(l);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.length && i < 40; i++) sb.append(i > 0 ? ", " : "").append(l[i]);
        return sb.toString();
    }

    private void say(String s) {
        try { pc("log", s); } catch (Throwable ignored) {}
    }
}
