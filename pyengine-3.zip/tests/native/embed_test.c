/* проверка C-прослойки на хосте: настоящий CPython, но JNI подделан */
#include <stdarg.h>
#include <stdio.h>
#include "../../native/pyjni.c"

static jstring f_new(JNIEnv *e, const char *s) { (void)e; return (jstring)strdup(s); }
static const char *f_get(JNIEnv *e, jstring s, jboolean *c) { (void)e; (void)c; return (const char *)s; }
static void f_rel(JNIEnv *e, jstring s, const char *c) { (void)e; (void)s; (void)c; }
static void f_del(JNIEnv *e, jobject o) { (void)e; (void)o; }
static jobject f_call(JNIEnv *e, jclass c, jmethodID m, ...) {
    (void)e; (void)c; (void)m;
    va_list ap; va_start(ap, m);
    const char *op = va_arg(ap, const char *);
    const char *t = va_arg(ap, const char *);
    const char *n = va_arg(ap, const char *);
    const char *a = va_arg(ap, const char *);
    va_end(ap);
    printf("[java<-py] op=%s target=%s name=%s args=%s\n", op, t, n, a);
    return (jobject)strdup("v:");
}
static jboolean f_exc(JNIEnv *e) { (void)e; return 0; }
static void f_clr(JNIEnv *e) { (void)e; }
static jobject f_glob(JNIEnv *e, jobject o) { (void)e; return o; }
static jmethodID f_mid(JNIEnv *e, jclass c, const char *n, const char *s) { (void)e; (void)c; (void)n; (void)s; return (jmethodID)1; }

static struct JNINativeInterface_ table = {
    f_new, f_get, f_rel, f_del, f_call, f_exc, f_clr, f_glob, f_mid
};
static jint v_getenv(JavaVM *vm, void **env, jint ver);
static jint v_attach(JavaVM *vm, JNIEnv **env, void *a);
static struct JNIInvokeInterface_ vtable = { v_getenv, v_attach };
static JNIEnv env_obj = &table;
static JavaVM vm_obj = &vtable;
static jint v_getenv(JavaVM *vm, void **env, jint ver) { (void)vm; (void)ver; *env = &env_obj; return 0; }
static jint v_attach(JavaVM *vm, JNIEnv **env, void *a) { (void)vm; (void)a; *env = &env_obj; return 0; }

int main(int argc, char **argv) {
    (void)argc;
    JNIEnv *env = &env_obj;
    JNI_OnLoad(&vm_obj, NULL);
    Java_cat_pyengine_Bridge_nInit(env, (jclass)"cls", (jstring)argv[1], (jstring)argv[2], (jstring)argv[3]);
    printf("ready=%d\n", g_ready);
    jstring r = Java_cat_pyengine_Bridge_nDispatch(env, (jclass)"cls", (jstring)"region", (jstring)"s:a,s:b");
    printf("region -> %s\n", r ? (const char *)r : "(null)");
    r = Java_cat_pyengine_Bridge_nDispatch(env, (jclass)"cls", (jstring)"resumed", (jstring)"h:1:x.Y");
    printf("resumed -> %s\n", r ? (const char *)r : "(null)");
    return 0;
}
