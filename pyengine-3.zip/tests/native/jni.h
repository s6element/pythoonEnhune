#ifndef FAKE_JNI_H
#define FAKE_JNI_H
#include <stddef.h>
typedef int jint; typedef unsigned char jboolean;
typedef void *jobject; typedef jobject jclass; typedef jobject jstring; typedef void *jmethodID;
#define JNIEXPORT __attribute__((visibility("default")))
#define JNICALL
#define JNI_OK 0
#define JNI_VERSION_1_6 0x00010006
struct JNINativeInterface_;
typedef const struct JNINativeInterface_ *JNIEnv;
struct JNIInvokeInterface_;
typedef const struct JNIInvokeInterface_ *JavaVM;
struct JNIInvokeInterface_ {
    jint (*GetEnv)(JavaVM *, void **, jint);
    jint (*AttachCurrentThread)(JavaVM *, JNIEnv **, void *);
};
struct JNINativeInterface_ {
    jstring (*NewStringUTF)(JNIEnv *, const char *);
    const char *(*GetStringUTFChars)(JNIEnv *, jstring, jboolean *);
    void (*ReleaseStringUTFChars)(JNIEnv *, jstring, const char *);
    void (*DeleteLocalRef)(JNIEnv *, jobject);
    jobject (*CallStaticObjectMethod)(JNIEnv *, jclass, jmethodID, ...);
    jboolean (*ExceptionCheck)(JNIEnv *);
    void (*ExceptionClear)(JNIEnv *);
    jobject (*NewGlobalRef)(JNIEnv *, jobject);
    jmethodID (*GetStaticMethodID)(JNIEnv *, jclass, const char *, const char *);
};
#endif
