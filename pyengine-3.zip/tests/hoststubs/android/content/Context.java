package android.content;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class Context {
    public static File files;
    private final Map<String, String> store = new HashMap<String, String>();

    public File getFilesDir() { return files; }
    public File getExternalFilesDir(String type) { return null; }

    public SharedPreferences getSharedPreferences(String name, int mode) {
        return new SharedPreferences() {
            public String getString(String k, String d) {
                String v = store.get(name + "/" + k);
                return v == null ? d : v;
            }
            public Editor edit() {
                return new Editor() {
                    public Editor putString(String k, String v) { store.put(name + "/" + k, v); return this; }
                    public void apply() {}
                };
            }
        };
    }
}
