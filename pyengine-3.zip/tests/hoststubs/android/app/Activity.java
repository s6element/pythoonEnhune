package android.app;
public class Activity {
    public String getLocalClassName() { return "FakeActivity"; }
}
