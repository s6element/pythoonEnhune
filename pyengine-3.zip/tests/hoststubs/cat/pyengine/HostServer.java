package cat.pyengine;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.PrintStream;

/** тестовый сервер: Python шлёт CALL, получает RET; по дороге могут прилететь LOG и CB (колбэк в питон). */
public class HostServer {
    public static void main(String[] args) throws Exception {
        final BufferedReader in = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
        final PrintStream out = new PrintStream(System.out, true, "UTF-8");
        android.content.Context.files = new File(args[1]);
        Bridge.appContext = new android.content.Context();
        Bridge.folder = args[0];
        Bridge.logger = new Bridge.Logger() {
            public void log(String s) { out.println("LOG\t" + Bridge.enc(s)); }
        };
        Bridge.dispatcher = new Bridge.Dispatcher() {
            public String dispatch(String n, String a) {
                out.println("CB\t" + n + "\t" + a);
                try {
                    String l = in.readLine();
                    return l.substring("CBRET\t".length());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        };
        String line;
        while ((line = in.readLine()) != null) {
            String[] p = line.split("\t", -1);
            if (p[0].equals("CALL")) out.println("RET\t" + Bridge.call(p[1], p[2], p[3], p[4]));
        }
    }
}
