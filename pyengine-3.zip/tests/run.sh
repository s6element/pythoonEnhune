#!/usr/bin/env bash
# хост-тест: Java-мост + питоновский SDK, без телефона
set -euo pipefail
cd "$(dirname "$0")/.."
rm -rf build/host && mkdir -p build/host
java -m jdk.compiler/com.sun.tools.javac.Main -d build/host $(find stubs plugin/java tests/hoststubs -name '*.java')
python3 tests/host_test.py
