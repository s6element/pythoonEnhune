import os, shutil, subprocess, sys, tempfile, types
from urllib.parse import unquote

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.path.join(ROOT, "build", "host")
sys.path.insert(0, os.path.join(ROOT, "py"))

work = tempfile.mkdtemp()
files = os.path.join(work, "files")
folder = os.path.join(work, "folder")
os.makedirs(files); os.makedirs(folder)

proc = subprocess.Popen(["java", "-cp", BUILD, "cat.pyengine.HostServer", folder, files],
                        stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, encoding="utf-8")
logs = []

def mt_call(op, target, name, args):
    proc.stdin.write("CALL\t%s\t%s\t%s\t%s\n" % (op, target, name, args)); proc.stdin.flush()
    while True:
        line = proc.stdout.readline().rstrip("\n")
        k, _, rest = line.partition("\t")
        if k == "RET":
            return rest
        if k == "LOG":
            logs.append(unquote(rest)); print("  [log]", logs[-1].splitlines()[0]); continue
        if k == "CB":
            n, _, a = rest.partition("\t")
            r = _engine.dispatch(n, a)
            proc.stdin.write("CBRET\t%s\n" % r); proc.stdin.flush(); continue
        raise RuntimeError("сервер умер: %r" % line)

mt = types.ModuleType("_mt"); mt.call = mt_call
sys.modules["_mt"] = mt
import java, _engine  # noqa
from java import jclass, dynamic_proxy, JavaError

ok = 0
def check(name, got, want):
    global ok
    assert got == want, "%s: %r != %r" % (name, got, want)
    ok += 1; print("ok ", name)

AL = jclass("java.util.ArrayList")
l = AL()
for x in (5, 3, 9, 1): l.add(x)
check("list size", l.size(), 4)
check("list get", l.get(2), 9)
check("static int overload", jclass("java.lang.Math").max(3, 7), 7)
check("static double", jclass("java.lang.Math").sqrt(16.0), 4.0)
check("static field", jclass("java.lang.Integer").MAX_VALUE, 2147483647)
check("valueOf(long)", jclass("java.lang.String").valueOf(12), "12")
check("unicode roundtrip", jclass("java.lang.String").valueOf("привет, мир 🙂 + %"), "привет, мир 🙂 + %")
check("bool", l.isEmpty(), False)
check("str(obj)", str(l), "[5, 3, 9, 1]")
sb = jclass("java.lang.StringBuilder")()
sb.append("a").append(1).append(True)
check("chain", str(sb), "a1true")
check("nested class", jclass("java.util.Map").Entry._n, "java.util.Map$Entry")

try:
    l.nope()
    raise SystemExit("должно было упасть")
except AttributeError:
    ok += 1; print("ok  attr error")
try:
    l.get(99)
    raise SystemExit("должно было упасть")
except JavaError as e:
    ok += 1; print("ok  java exception ->", str(e)[:50])

class Cmp(dynamic_proxy(jclass("java.util.Comparator"))):
    def compare(self, a, b):
        return (a > b) - (a < b)
jclass("java.util.Collections").sort(l, Cmp())
check("sort via python callback", str(l), "[1, 3, 5, 9]")

hits = []
class R(dynamic_proxy(jclass("java.lang.Runnable"))):
    def run(self): hits.append(1)
r = R(); r.run_ = None
jclass("java.lang.Thread")(r).run()
check("runnable callback", hits, [1])

arr = jclass("java.lang.String")("a,b,c").split(",")
check("array len", len(arr), 3)
check("array iter", list(arr), ["a", "b", "c"])

# ---- движок: настоящий .plugin ----
pdir = os.path.join(files, "pyplugins")
os.makedirs(pdir, exist_ok=True)
with open(os.path.join(pdir, "t.plugin"), "w", encoding="utf-8") as f:
    f.write('''__id__ = "t_plug"
__name__ = "T"
__version__ = "9"
from base_plugin import BasePlugin
from android_utils import log
class T(BasePlugin):
    def on_plugin_load(self):
        log("loaded")
        self.set_setting("n", {"a": [1, 2]})
    def on_activity_resumed(self, activity):
        log("resumed", activity.getLocalClassName(), self.get_setting("n"))
    def on_region(self, key, value):
        return value.upper() if key == "sim_country" else value
''')
_engine.start()
check("plugin loaded", any("загружен t_plug 9" in s for s in logs), True)
_alive = []
def fresh():
    # как в живом движке: на каждый вызов хука Java заводит новый хэндл, Python им владеет
    o = jclass("android.app.Activity")()
    _alive.append(o)  # держим до конца диспатча, иначе хэндл освободится раньше
    return "h:%d:android.app.Activity" % o._h
_engine.dispatch("resumed", fresh())
check("resumed hook", any("resumed FakeActivity {'a': [1, 2]}" in s for s in logs), True)
check("region hook", _engine.dispatch("region", "s:sim_country,s:ru"), "s:RU")
check("region passthrough", _engine.dispatch("region", "s:x,s:ru"), "s:ru")

# битый плагин не должен ронять остальные
with open(os.path.join(pdir, "bad.plugin"), "w") as f:
    f.write("raise ValueError('oops')\n")
_engine._last_scan = 0
_engine.dispatch("resumed", fresh())
check("bad plugin logged", any("не загрузился" in s and "oops" in s for s in logs), True)
check("no hook errors", any("on_activity_resumed" in x and "Traceback" in x for x in logs), False)
_engine.dispatch("stop", "")
check("stopped", _engine._loaded, {})

proc.stdin.close(); proc.wait(timeout=5)
shutil.rmtree(work)
print("\nвсё ок: %d проверок" % ok)
